package com.beltaria.damageengine.api;

/**
 * The canonical damage pipeline, as a pure function so it can be unit-tested
 * without a running server.
 *
 * <pre>
 * damage = (base + flatBonus)
 *        × max(0, 1 + Σ increased)          additive offense
 *        × Π (1 + more_i)                   multiplicative offense
 *        × max(0, 1 + Σ takenIncreased)     additive defense (vulnerability / reduction)
 *        × Π (1 + takenMore_i)              multiplicative defense (fortify-style)
 *        − flatReduction                    flat last, floored at 0
 * </pre>
 */
public final class DamageFormula {

    private DamageFormula() {
    }

    public static double compute(double base,
                                 double flatBonus,
                                 double increasedSum,
                                 double moreProduct,
                                 double takenSum,
                                 double takenMoreProduct,
                                 double flatReduction) {
        double damage = (base + flatBonus)
                * Math.max(0.0, 1.0 + increasedSum)
                * moreProduct
                * Math.max(0.0, 1.0 + takenSum)
                * takenMoreProduct;
        return Math.max(0.0, damage - flatReduction);
    }
}
