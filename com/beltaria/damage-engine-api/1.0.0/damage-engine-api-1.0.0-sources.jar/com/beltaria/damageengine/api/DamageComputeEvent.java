package com.beltaria.damageengine.api;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.bukkit.entity.Entity;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

/**
 * Fired once per Bukkit damage event, before the final damage is written back.
 *
 * <p>Plugins hook damage by listening to THIS event and declaring typed
 * modifiers instead of calling {@code EntityDamageEvent#setDamage} themselves.
 * Every category combines commutatively (sums and products), so the result is
 * independent of plugin load/listener order.</p>
 *
 * <p>Naming contract — the verb tells you how it stacks, the argument shape
 * tells you what to pass:</p>
 * <ul>
 *   <li>{@code add*} methods take a <b>fraction</b> and stack by SUMMATION:
 *       {@code addPercentDamage(0.05)} = +5%, two of them = +10%.</li>
 *   <li>{@code multiply*} methods take a <b>factor</b> and stack by MULTIPLICATION:
 *       {@code multiplyDamage(1.10)} = ×1.10, {@code multiplyDamage(0.90)} = −10% multiplicative.</li>
 *   <li>{@code *Damage} targets the hit itself (attacker side);
 *       {@code *DamageTaken} targets what the victim receives (defense side).</li>
 * </ul>
 *
 * <p>Pipeline order (fixed, not affected by call order):</p>
 * <pre>
 * damage = (base + Σ flatDamage)
 *        × (1 + Σ percentDamage)          additive offense
 *        × Π damageFactor                 multiplicative offense
 *        × (1 + Σ percentDamageTaken)     additive defense
 *        × Π damageTakenFactor            multiplicative defense
 *        − Σ flatDamageReduction          flat last, floored at 0
 * </pre>
 *
 * <p>The value produced here is written back with {@code setDamage(double)},
 * i.e. it is the <b>pre-mitigation base damage</b>: vanilla armor, Protection
 * enchantments, potion Resistance and absorption still apply afterwards.</p>
 *
 * <p>Recommended listener phases: LOW = classification (tags), NORMAL =
 * modifiers, HIGH = final adjustments/caps, MONITOR = read-only
 * ({@link #previewDamage()}).</p>
 */
public class DamageComputeEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Entity victim;
    private final Entity attacker;      // resolved: shooter for projectiles, igniter for TNT; null for environment
    private final Entity directDamager; // the arrow / TNT entity itself; null if not entity-caused
    private final DamageCause cause;
    private final double baseDamage;
    private final Set<String> tags = new HashSet<String>();
    private final Map<ContextKey<?>, Object> context = new HashMap<ContextKey<?>, Object>();

    private double flatDamageSum = 0.0;
    private double percentDamageSum = 0.0;
    private double damageFactorProduct = 1.0;
    private double percentDamageTakenSum = 0.0;
    private double damageTakenFactorProduct = 1.0;
    private double flatDamageReductionSum = 0.0;
    private boolean cancelled = false;

    public DamageComputeEvent(Entity victim, Entity attacker, Entity directDamager,
                              DamageCause cause, double baseDamage) {
        this.victim = victim;
        this.attacker = attacker;
        this.directDamager = directDamager;
        this.cause = cause;
        this.baseDamage = baseDamage;
    }

    // ---------- offense (attacker side) ----------

    /**
     * Flat damage (half-hearts) added BEFORE all percentage modifiers,
     * so it benefits from them. Stacks by summation.
     */
    public void addFlatDamage(double amount) {
        this.flatDamageSum += requireFinite(amount);
    }

    /**
     * Additive percentage bonus/malus, as a fraction. Stacks by SUMMATION:
     * {@code addPercentDamage(0.05)} twice = +10% total, not ×1.05².
     * Negative values reduce; the summed total is floored at −100%.
     */
    public void addPercentDamage(double fraction) {
        this.percentDamageSum += requireFinite(fraction);
    }

    /**
     * Multiplicative modifier, as a factor. Stacks by MULTIPLICATION:
     * {@code multiplyDamage(1.30)} = the hit deals ×1.30,
     * {@code multiplyDamage(0.90)} = ×0.90.
     * Reserve this for rare, controlled effects (ultimates, keystones) —
     * freely stackable sources belong in {@link #addPercentDamage(double)}.
     *
     * @throws IllegalArgumentException if factor is negative or not finite
     */
    public void multiplyDamage(double factor) {
        this.damageFactorProduct *= requireNonNegativeFactor(factor);
    }

    // ---------- defense (victim side) ----------

    /**
     * Additive percentage on damage the victim takes, as a fraction.
     * {@code addPercentDamageTaken(0.30)} = vulnerability (+30% taken),
     * {@code addPercentDamageTaken(-0.20)} = reduction (−20% taken).
     * Stacks by summation, summed total floored at −100%.
     */
    public void addPercentDamageTaken(double fraction) {
        this.percentDamageTakenSum += requireFinite(fraction);
    }

    /**
     * Multiplicative modifier on damage the victim takes, as a factor.
     * {@code multiplyDamageTaken(0.85)} = fortify-style, victim takes ×0.85.
     * Cannot be diluted by additive stacking — use for guaranteed defenses.
     *
     * @throws IllegalArgumentException if factor is negative or not finite
     */
    public void multiplyDamageTaken(double factor) {
        this.damageTakenFactorProduct *= requireNonNegativeFactor(factor);
    }

    /**
     * Flat reduction (half-hearts) applied LAST, after all percentages —
     * strong against small hits, negligible against big ones. Result is
     * floored at 0: it can never turn damage into healing.
     */
    public void addFlatDamageReduction(double amount) {
        this.flatDamageReductionSum += requireFinite(amount);
    }

    // ---------- computation ----------

    /**
     * Damage as it would be written back if no further listener modifies the
     * event. Listeners at later priorities may still change it; only read
     * this as final from MONITOR priority.
     */
    public double previewDamage() {
        return DamageFormula.compute(baseDamage, flatDamageSum, percentDamageSum,
                damageFactorProduct, percentDamageTakenSum, damageTakenFactorProduct,
                flatDamageReductionSum);
    }

    // ---------- context ----------

    public Entity getVictim() {
        return victim;
    }

    /** Resolved attacker (projectile shooter, TNT source). Null for environmental damage. */
    public Entity getAttacker() {
        return attacker;
    }

    /** The entity that physically dealt the hit (arrow, TNT). Null if not entity-caused. */
    public Entity getDirectDamager() {
        return directDamager;
    }

    public DamageCause getCause() {
        return cause;
    }

    /** Vanilla base damage before any engine modifier. */
    public double getBaseDamage() {
        return baseDamage;
    }

    // ---------- inter-plugin communication ----------

    /**
     * Attach a typed value for other plugins to read at a later listener phase.
     * Write at LOW (classification), read at NORMAL and later.
     */
    public <T> void putContext(ContextKey<T> key, T value) {
        // cast at the boundary: a wrong-typed put fails HERE, at the writer,
        // not later at some unrelated reader
        context.put(key, key.getType().cast(value));
    }

    /** @return the value for this key, or null if no plugin wrote it. */
    public <T> T getContext(ContextKey<T> key) {
        Object value = context.get(key);
        if (value == null) {
            return null;
        }
        try {
            return key.getType().cast(value);
        } catch (ClassCastException e) {
            throw new IllegalStateException("Context key '" + key
                    + "' was written by another plugin with incompatible type "
                    + value.getClass().getName() + " (expected " + key.getType().getName()
                    + ") — the two plugins disagree on the key's contract", e);
        }
    }

    public <T> T getContextOrDefault(ContextKey<T> key, T defaultValue) {
        T value = getContext(key);
        return value != null ? value : defaultValue;
    }

    public boolean hasContext(ContextKey<?> key) {
        return context.containsKey(key);
    }

    /** Free-form tags so plugins can coordinate, e.g. "spell", "true-damage", "boss-phase-2". */
    public void addTag(String tag) {
        tags.add(tag);
    }

    public boolean hasTag(String tag) {
        return tags.contains(tag);
    }

    public Set<String> getTags() {
        return Collections.unmodifiableSet(tags);
    }

    // ---------- raw accumulators (debug / damage-indicator plugins) ----------

    public double getFlatDamageSum() {
        return flatDamageSum;
    }

    public double getPercentDamageSum() {
        return percentDamageSum;
    }

    public double getDamageFactorProduct() {
        return damageFactorProduct;
    }

    public double getPercentDamageTakenSum() {
        return percentDamageTakenSum;
    }

    public double getDamageTakenFactorProduct() {
        return damageTakenFactorProduct;
    }

    public double getFlatDamageReductionSum() {
        return flatDamageReductionSum;
    }

    // ---------- boilerplate ----------

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    private static double requireFinite(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            throw new IllegalArgumentException("Damage modifier must be finite, got: " + value);
        }
        return value;
    }

    private static double requireNonNegativeFactor(double factor) {
        requireFinite(factor);
        if (factor < 0.0) {
            throw new IllegalArgumentException(
                    "Multiplicative factor must be >= 0 (got " + factor
                    + "). Did you pass a fraction? multiplyDamage takes a FACTOR: 1.10 for +10%.");
        }
        return factor;
    }
}
