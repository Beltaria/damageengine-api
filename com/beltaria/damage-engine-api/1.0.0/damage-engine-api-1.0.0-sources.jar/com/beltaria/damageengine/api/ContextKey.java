package com.beltaria.damageengine.api;

/**
 * Typed, namespaced key for passing structured values between plugins on a
 * {@link DamageComputeEvent} (type-safe heterogeneous container pattern).
 *
 * <p>Equality is by id only: two plugins declaring
 * {@code ContextKey.of("spellcore:school", String.class)} interoperate WITHOUT
 * sharing a jar — the string id is the contract. Sharing a public constant
 * additionally gives compile-time safety, but is optional.</p>
 *
 * <p>Ids must be namespaced {@code "plugin:name"} to prevent collisions.</p>
 */
public final class ContextKey<T> {

    private final String id;
    private final Class<T> type;

    private ContextKey(String id, Class<T> type) {
        if (id == null || id.indexOf(':') <= 0) {
            throw new IllegalArgumentException(
                    "Context key id must be namespaced 'plugin:name', got: " + id);
        }
        if (type == null) {
            throw new IllegalArgumentException("Context key type must not be null");
        }
        this.id = id;
        this.type = type;
    }

    public static <T> ContextKey<T> of(String id, Class<T> type) {
        return new ContextKey<T>(id, type);
    }

    public String getId() {
        return id;
    }

    public Class<T> getType() {
        return type;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof ContextKey && ((ContextKey<?>) o).id.equals(id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        return id;
    }
}
