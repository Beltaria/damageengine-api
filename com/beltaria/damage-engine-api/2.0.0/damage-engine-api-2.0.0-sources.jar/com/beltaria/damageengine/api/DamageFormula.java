package com.beltaria.damageengine.api;

/**
 * The canonical damage pipeline, as a pure function so it can be unit-tested
 * without a running server.
 *
 * <pre>
 * damage = (base + flatBonus)
 *        × max(0, 1 + Σ increased)          additive offense
 *        × Π (1 + more_i)                   multiplicative offense
 *        × max(0, 1 + Σ takenIncreased)     additive defense (vulnerability / reduction)
 *        × Π (1 + takenMore_i)              multiplicative defense (fortify-style)
 *        − flatReduction                    flat last, floored at 0
 * </pre>
 */
public final class DamageFormula {

    private DamageFormula() {
    }

    public static double compute(double base,
                                 double flatBonus,
                                 double increasedSum,
                                 double moreProduct,
                                 double takenSum,
                                 double takenMoreProduct,
                                 double flatReduction) {
        double damage = (base + flatBonus)
                * Math.max(0.0, 1.0 + increasedSum)
                * moreProduct
                * Math.max(0.0, 1.0 + takenSum)
                * takenMoreProduct;
        return Math.max(0.0, damage - flatReduction);
    }

    /**
     * The same pipeline for a hit landing in the victim's hit window. The server then passes only the
     * excess over the window's raw hit ({@code f − lastDamage}), so applying the formula to that excess
     * would add every flat term a second time. The engine deals the excess of ITS damage instead:
     * {@code max(0, F(base + lastDamage) − already dealt)}, where "already dealt" is what the engine
     * dealt to the window's earlier hits ({@link DamageWindow#getDealt()}), or, when it has no record of
     * them, {@code F(lastDamage)} with this hit's modifiers. Over a window the hits then deal together
     * the strongest engine damage among them, as vanilla does with raw damage.
     *
     * @param base the damage the server passes: the whole hit, or its excess in a window
     */
    public static double computeInWindow(double base,
                                         DamageWindow window,
                                         double flatBonus,
                                         double increasedSum,
                                         double moreProduct,
                                         double takenSum,
                                         double takenMoreProduct,
                                         double flatReduction) {
        double whole = compute(base + window.getLastDamage(), flatBonus, increasedSum, moreProduct, takenSum,
                takenMoreProduct, flatReduction);
        if (!window.isOpen()) {
            return whole;
        }
        double already = window.isKnown() ? window.getDealt()
                : compute(window.getLastDamage(), flatBonus, increasedSum, moreProduct, takenSum, takenMoreProduct,
                        flatReduction);
        return Math.max(0.0, whole - already);
    }
}
