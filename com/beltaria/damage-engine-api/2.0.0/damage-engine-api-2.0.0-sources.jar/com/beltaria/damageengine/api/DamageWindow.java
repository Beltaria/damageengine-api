package com.beltaria.damageengine.api;

/**
 * The victim's hit window as a hit finds it. Immutable.
 *
 * <p>In 1.8, for half of {@code maxNoDamageTicks} after a hit, a weaker or equal hit does nothing and
 * a stronger one is passed to the server as the excess only ({@code f − lastDamage}). The engine keeps,
 * per victim, what it dealt to the hits of the current window, so a hit landing there deals the excess
 * of the engine's damage over what was already dealt, whoever dealt it (an arrow, a fall, another
 * player) and whatever bonuses that hit had.</p>
 */
public final class DamageWindow {

    /** A hit that opens a window: nothing dealt before it. */
    public static final DamageWindow NONE = new DamageWindow(0.0, 0.0, 0.0, true);

    private final double lastDamage;
    private final double dealt;
    private final double trueDealt;
    private final boolean known;

    private DamageWindow(double lastDamage, double dealt, double trueDealt, boolean known) {
        this.lastDamage = lastDamage;
        this.dealt = dealt;
        this.trueDealt = trueDealt;
        this.known = known;
    }

    /**
     * A hit in a window whose earlier hits the engine computed.
     *
     * @param lastDamage the server's raw {@code lastDamage}, {@code > 0}
     * @param dealt the engine damage (formula result) already dealt in this window, {@code >= 0}
     * @param trueDealt the true damage already dealt in this window, {@code >= 0}
     */
    public static DamageWindow known(double lastDamage, double dealt, double trueDealt) {
        return new DamageWindow(requirePositive(lastDamage), requireNonNegative(dealt),
                requireNonNegative(trueDealt), true);
    }

    /**
     * A hit in a window the engine has no record of (opened by a hit it did not see through). The
     * opening hit is then assumed to have had this hit's modifiers.
     *
     * @param lastDamage the server's raw {@code lastDamage}, {@code > 0}
     */
    public static DamageWindow unknown(double lastDamage) {
        return new DamageWindow(requirePositive(lastDamage), 0.0, 0.0, false);
    }

    /** Whether this hit lands in an open window, so the server passes only its excess. */
    public boolean isOpen() {
        return lastDamage > 0.0;
    }

    /** The server's raw {@code lastDamage} this hit is passed over; 0 for a hit that opens a window. */
    public double getLastDamage() {
        return lastDamage;
    }

    /** Whether the engine knows what the window's earlier hits dealt ({@link #getDealt()}). */
    public boolean isKnown() {
        return known;
    }

    /** Engine damage already dealt in this window; meaningful only when {@link #isKnown()}. */
    public double getDealt() {
        return dealt;
    }

    /** True damage already dealt in this window; meaningful only when {@link #isKnown()}. */
    public double getTrueDealt() {
        return trueDealt;
    }

    @Override
    public String toString() {
        return !isOpen() ? "DamageWindow[none]"
                : "DamageWindow[lastDamage=" + lastDamage + (known ? ", dealt=" + dealt + ", trueDealt=" + trueDealt
                        : ", unknown") + "]";
    }

    private static double requireNonNegative(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value) || value < 0.0) {
            throw new IllegalArgumentException("Window value must be finite and >= 0, got: " + value);
        }
        return value;
    }

    private static double requirePositive(double value) {
        if (requireNonNegative(value) == 0.0) {
            throw new IllegalArgumentException("An open window has a lastDamage > 0 (use NONE otherwise)");
        }
        return value;
    }
}
